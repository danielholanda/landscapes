# This import registers the 3D projection, but is otherwise unused.
from mpl_toolkits.mplot3d import Axes3D 

import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np

# Print info
print("This script requires Python3")

# Create Figure
fig = plt.figure()
ax = fig.gca(projection='3d')

# Load data
np_load_old = np.load
np.load = lambda *a,**k: np_load_old(*a, allow_pickle=True, **k)
alpha,beta,loss_landscape,acc = np.load("landscape_epoch_95.npy")
X, Y = alpha,beta
Z = loss_landscape
X, Y = np.meshgrid(X, Y)


# Clip values
Z=np.clip(Z, 0, .8)

# Reshape array
dim=int(np.sqrt(len(Z)))
Z=Z.reshape((dim, dim))

# Plot the surface.
surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm,linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

# Print info
print("To recreate the paper/thesis plot, convert landscape to a surface file and open with ParaView.")

plt.show()