# Run this python3 script using tensorflow 2.2.0

from sklearn.datasets import make_circles
from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.initializers import RandomUniform
from tensorflow.keras.layers import *
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.callbacks import TensorBoard
from numpy import where
import matplotlib.pyplot as plt
from numpy.random import seed
import numpy as np
from tensorflow import keras
import sys
seed(1)
from tensorflow.keras import backend as K
seed_number=4242
tf.compat.v1.random.set_random_seed(seed_number)

from tensorflow.keras import layers
#from keras_buoy.models import ResumableModel

# Enable/Disable plotting 
plot_enabled=False

# Leaky or non-leaky relu
use_leaky_relu = False
use_small_network = False

# Change activation to leaky relu if needed
if use_leaky_relu:
    activation_name='linear'
else:
    activation_name='relu'

inputs = keras.Input(shape=(2,))
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(inputs)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
x = layers.Dense(5, activation=activation_name, kernel_initializer='he_uniform')(x)
if use_leaky_relu:
    x = layers.LeakyReLU()(x)
outputs = layers.Dense(1, activation="sigmoid")(x)

class raw_metric(tf.keras.metrics.Metric):
  def __init__(self, name='raw_values_tracker', **kwargs):
    super(raw_metric, self).__init__(name=name, **kwargs)
    self.raw = []

  def update_state(self, vals):
    self.raw=vals

  def result(self):
    return self.raw



class CustomModel(keras.Model):

    def train_step(self, data):
            # Unpack the data. Its structure depends on your model and
            # on what you pass to `fit()`.
            x, y = data
            print(x)
            print("----")

            with tf.GradientTape() as tape:
                y_pred = self(x, training=True)  # Forward pass
                loss = self.compiled_loss(y, y_pred, regularization_losses=self.losses)

            # Compute gradients
            trainable_vars = self.trainable_variables
            gradients = tape.gradient(loss, trainable_vars)
            # Update weights
            self.optimizer.apply_gradients(zip(gradients, trainable_vars))
            # Update metrics (includes the metric that tracks the loss)
            self.compiled_metrics.update_state(y, y_pred)

            # Return a dict mapping metric names to current value

            loss_tracker.update_state(loss)
            for i in range(len(gradients)):
                raw_tracker_grad[i].update_state(gradients[i])
            #for i in range(len(activations)):
            mean_gradient.update_state(gradients[2])
            return_dict = {**{"loss": loss_tracker.result()},**{"mean_gradient": mean_gradient.result()},**{m.name: m.result() for m in self.metrics}}
            for idx,grad_name in enumerate(gradients_names):
                return_dict[grad_name]=raw_tracker_grad[idx].result()
            return return_dict

model = CustomModel(inputs=inputs, outputs=outputs)
if use_leaky_relu:
    layers_to_track = []
    for l in model.layers[1:]:
        layer_config=l.get_config()
        if 'dense' in layer_config['name']:

            if layer_config['activation']!='linear':
                layers_to_track.append(l)
        else:
            layers_to_track.append(l)
else:
    layers_to_track = model.layers[1:]

layers_to_remove=7
starting_at_layer=4
if use_small_network:
    # Remove some of the intermediate layers
    for i in range(layers_to_remove):
        del layers_to_track[starting_at_layer]

model2 = CustomModel(inputs=inputs, outputs=[l.output for l in layers_to_track])

loss_tracker = keras.metrics.Mean(name="loss_tracker")
mean_gradient = keras.metrics.Mean(name="mean_gradient")

# load json and create model
print("Loading Model")
json_file = open('model/model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()

# load weights into new model
model.load_weights("model/model.h5")
X=np.load("model/x.npy")
y=np.load("model/y.npy")
n_train=500
trainX, testX = X[:n_train, :], X[n_train:, :]
trainy, testy = y[:n_train], y[n_train:]
print("Loaded weights")

if use_small_network:
    # Remove some of the intermediate layers
    for i in range(layers_to_remove):
        model._layers.pop(starting_at_layer)
        model2._layers.pop(starting_at_layer)
model.summary()

# Track the gradient values of each weights matrix
trainable_weights = model.trainable_weights
gradients_names = [t.name for t in trainable_weights]
raw_tracker_grad = [raw_metric(name=g) for g in gradients_names]

# compile model
opt = SGD(lr=0.01, momentum=0.9)
model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])
model2.compile(loss='binary_crossentropy', optimizer=opt,metrics=['accuracy'])

from tensorflow.keras.callbacks import Callback

class NBatchLogger(Callback):
    "A Logger that log average performance per `display` steps."
    def __init__(self):
        self.step = 0

    def on_batch_end(self, batch, logs={}):
        self.step += 1
        for n in gradients_names:
            raw_grads[n].append(logs[n])
        
        if self.step<20000000:
            # Get activations of all test set at every step
            #model2.set_weights(model.get_weights()) 
            #print(model.get_weights()[2])
            count=0
            for i in range(len(model.layers)):
                model2.layers[i].set_weights(model.layers[i].get_weights())
                if i!=0 and len(model.layers[i].get_weights())>0: # Skip input layer
                    weights_tracker[count].append(model.layers[i].get_weights()[0])
                    bias_tracker[count].append(model.layers[i].get_weights()[1])
                    count=count+1
            
            act = model2.predict(testX)
            for idx,a in enumerate(act):
                activation_tracker[idx].append(a)


tb =  NBatchLogger()

gradients_names
raw_grads = {n:[] for n in gradients_names}

activation_tracker = [[] for i in layers_to_track]
weights_tracker = [[] for i in layers_to_track]
bias_tracker = [[] for i in layers_to_track]

accuracy=[]
val_accuracy=[]

def random_direction_vector(w,normalize=True):
    # First, create vector with the same shape as w
    dv = []
    for set_of_weights in w:

        #print(set_of_weights.shape)
        shape=set_of_weights.shape

        # The bias is always zero in the direction vector
        if len(shape)==1:
            dv.append(set_of_weights*0)

        else:
            v=np.random.randn(shape[1], shape[0])

            # We are sapping axis to normalize the weights that contribute to a single neuron.
            # Note that the default order of np.linalg.norm is the frobenius norm
            if normalize:
                w_swaped = np.swapaxes(set_of_weights,0,1)
                v = [node_dir* np.linalg.norm(node_weight)/(np.linalg.norm(node_dir) + 1e-10) for node_dir, node_weight in zip(v,w_swaped)]
                v = np.swapaxes(v,0,1)
            dv.append(v)
    return np.array(dv)


total_epochs=100
for i in range(total_epochs):
    history = model.fit(trainX, trainy, validation_data=(testX, testy), batch_size=32, epochs=1, verbose=0, callbacks=[tb], shuffle=False)
    accuracy=accuracy+history.history['accuracy']
    val_accuracy=val_accuracy+history.history['val_accuracy']
    if i==95:

        print(f'Starting to get loss landscape for epoch {i}')
        # Select how many points per axis
        axis_steps = 50
        loss_landscape = np.zeros(axis_steps*axis_steps)
        acc_landscape = np.zeros(axis_steps*axis_steps)
        alpha=np.linspace(-.75,1.25,axis_steps)
        beta=np.linspace(-.75,1.25,axis_steps)

        # Saving weights and creating random direction vectors
        w = np.array(model.get_weights()) 
        n = random_direction_vector(w)
        d = random_direction_vector(w)

        # Get loss landscape
        for a_idx, a_val in enumerate(alpha):
            print(str(100.*(a_idx*axis_steps)/float(axis_steps*axis_steps))+"%")
            for b_idx, b_val in enumerate(beta):
                model.set_weights(w+a_val*n+b_val*d)
                loss, acc = model.evaluate(testX,testy)
                idx=a_idx*axis_steps+b_idx
                
                # Uncomment the following to recreate the sparsity landscape
                '''
                # Average sparsity of all samples per layer -> only storing the layer with largest sparsity
                max_sparsity=0
                model2.set_weights(w+a_val*n+b_val*d)
                act = model2.predict(testX)
                for layers in act:
                    l_sparsity = np.sum(np.count_nonzero(layers < 0.001, axis=0))/(len(layers)*len(layers[0]))
                    if l_sparsity>max_sparsity:
                        max_sparsity=l_sparsity
                #print(max_sparsity)
                '''

                loss_landscape[idx]=loss
                acc_landscape[idx]=acc
                


        # Save results and reset weights
        with open(f'landscape_epoch_{i}.npy', 'wb') as f:
            np.save(f, [alpha,beta,loss_landscape,acc])
        model.set_weights(w)                  

# evaluate the model
_, train_acc = model.evaluate(trainX, trainy, verbose=0)
_, test_acc = model.evaluate(testX, testy, verbose=0)
print('Train: %.3f, Test: %.3f' % (train_acc, test_acc))


array_to_save = [accuracy, val_accuracy, activation_tracker, gradients_names, raw_grads, weights_tracker, bias_tracker]
np.save(f'{seed_number}_plot_vals', array_to_save)